# -*- coding: UTF-8 -*-

import numpy as np
from pysnptools.snpreader import Bed
from scipy import linalg
import pandas as pd

###构建G矩阵###
# PLINK bed文件名
bed_file = 'plink'
# 读取数据
M = Bed(bed_file, count_A1=False).read()
# 计算每个位点的等位基因频率，可以搜一下np.sum的详细使用方式
freq = np.sum(M.val, axis=0) / (2 * M.iid_count)
# 计算标准化因子
scale = np.sum(2 * freq * (1 - freq))
# 计算Z矩阵
Z = M.val - 2 * freq
# 计算G矩阵
G = np.dot(Z, Z.T) / scale
#对角线向量加0.001
d = np.diag(G) + 0.001
#替换原来的G矩阵对角线
np.fill_diagonal(G, d)
#求逆
Ginv = linalg.inv(G)

#读取数据文件
data_file = 'phe'
data = pd.read_table(data_file, header=0, sep = '\s+')
print data.head()

#表型向量
y = np.array(data['phe'], dtype = np.float)

#固定效应设计矩阵，选出的是mean、sex、age、treat
X = np.array(data.loc[:,'mean':'treat'], dtype = np.float)

#随机效应设计矩阵
num = len(y)
Z =  np.eye(num)

#W矩阵，利用np.concatenate函数，行方向上拼接数组
W = np.concatenate((X, Z), axis = 1)

#构建W’R-1W
C = np.dot(W.T, W)/0.139

#构建系数矩阵
C[X.shape[1]:,X.shape[1]:] += Ginv/0.088

#系数矩阵右手项
RHS = np.dot(W.T, y)/ 0.139

#求解混合模型方程组
effect = linalg.solve(C, RHS)

fix_eff = effect[:X.shape[1]]  #固定效应部分
ran_eff = effect[X.shape[1]:,] #随机效应部分

####下面介绍如何对固定效应检验，如何求可靠性
# 系数矩阵求逆
Ci = linalg.inv(C)

# 固定效应整体检验（包括均值），备择假设为至少有一个显著
covi = linalg.inv(Ci[:X.shape[1], :X.shape[1]])  # 估计值方差协方差矩阵的逆
chi_val = np.dot(fix_eff.T, np.dot(covi, fix_eff))  # 卡方值
from scipy.stats import chi2  # 加载卡方分布的库
p1 = chi2.sf(chi_val, 4)  # 转化为P值

# 除均值外的其他效应的检验
covi = linalg.inv(Ci[1:X.shape[1], 1:X.shape[1]])
chi_val = np.dot(fix_eff[1:X.shape[1]].T, np.dot(covi, fix_eff[1:X.shape[1]]))
p2 = chi2.sf(chi_val, 3)  # 转化为P值

# 对处理效应(treat)进行检验
var = 1.0 / Ci[3, 3]
eff = fix_eff[3]
chi_val = eff * eff / var
p3 = chi2.sf(chi_val, 1)

print p1, p2, p3
# 可见包含均值的所有固定效应的检验非常显著，P值近似为0，treat效应不显著


# 育种值的可靠性计算
PEV = np.diag(Ci[X.shape[1]:, X.shape[1]:])  # 取系数矩阵随机效应部分的对角线，即为PEV
R2 = 1 - PEV / 0.088
# 输出可靠性的最大、最小值
print max(R2), min(R2)  # 可靠性比较高，可能由于所有个体都表型




